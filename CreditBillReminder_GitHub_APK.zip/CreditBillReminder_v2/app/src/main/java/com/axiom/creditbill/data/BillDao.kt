package com.axiom.creditbill.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao interface BillDao {
 @Query("SELECT * FROM bills ORDER BY paid ASC, dueAt ASC") fun observe():Flow<List<Bill>>
 @Query("SELECT * FROM bills WHERE id=:id LIMIT 1") suspend fun get(id:Long):Bill?
 @Query("SELECT * FROM bills") suspend fun getAll():List<Bill>
 @Insert suspend fun insert(bill:Bill):Long
 @Update suspend fun update(bill:Bill)
 @Delete suspend fun delete(bill:Bill)
}
