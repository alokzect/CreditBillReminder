package com.axiom.creditbill.data
import android.content.Context
import androidx.room.*
@Database(entities=[Bill::class],version=1,exportSchema=false)
abstract class AppDatabase:RoomDatabase(){
 abstract fun dao():BillDao
 companion object { @Volatile private var I:AppDatabase?=null
  fun get(c:Context)=I?:synchronized(this){I?:Room.databaseBuilder(c.applicationContext,AppDatabase::class.java,"credit_bill.db").build().also{I=it}}
 }
}
