package com.axiom.creditbill.worker

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.axiom.creditbill.data.Bill
import java.util.Calendar

object ReminderScheduler {
    private const val ACTION = "com.axiom.creditbill.REMINDER"
    private const val KIND_REMINDER = 1
    private const val KIND_DUE = 2

    private fun requestCode(id: Long, kind: Int): Int =
        ((id * 31 + kind) and 0x7fffffff).toInt()

    fun canScheduleExact(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        return context.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    }

    fun schedule(context: Context, bill: Bill) {
        cancel(context, bill.id)
        if (bill.paid) return

        val alarmManager = context.getSystemService(AlarmManager::class.java)
        val now = System.currentTimeMillis()

        val reminder = Calendar.getInstance().apply {
            timeInMillis = bill.dueAt
            add(Calendar.DAY_OF_YEAR, -bill.reminderDays)
            set(Calendar.HOUR_OF_DAY, bill.reminderHour)
            set(Calendar.MINUTE, bill.reminderMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        if (bill.reminderDays > 0 && reminder.timeInMillis > now) {
            setAlarm(context, alarmManager, reminder.timeInMillis, bill.id, false, requestCode(bill.id, KIND_REMINDER))
        }

        val due = Calendar.getInstance().apply {
            timeInMillis = bill.dueAt
            set(Calendar.HOUR_OF_DAY, bill.reminderHour)
            set(Calendar.MINUTE, bill.reminderMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        if (due.timeInMillis > now) {
            setAlarm(context, alarmManager, due.timeInMillis, bill.id, true, requestCode(bill.id, KIND_DUE))
        }
    }

    private fun setAlarm(
        context: Context,
        alarmManager: AlarmManager,
        triggerAt: Long,
        billId: Long,
        dueToday: Boolean,
        requestCode: Int
    ) {
        val intent = Intent(context, ReminderReceiver::class.java)
            .setAction(ACTION)
            .putExtra("billId", billId)
            .putExtra("dueToday", dueToday)

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Exact alarms are preferred. If the user has not granted the Android
        // 12+ exact-alarm access, fall back to an inexact idle-safe alarm rather
        // than crashing the app with SecurityException.
        if (canScheduleExact(context)) {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerAt,
                pendingIntent
            )
        } else {
            alarmManager.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerAt,
                pendingIntent
            )
        }
    }

    fun cancel(context: Context, billId: Long) {
        val alarmManager = context.getSystemService(AlarmManager::class.java)

        listOf(KIND_REMINDER, KIND_DUE).forEach { kind ->
            val intent = Intent(context, ReminderReceiver::class.java)
                .setAction(ACTION)

            val pendingIntent = PendingIntent.getBroadcast(
                context,
                requestCode(billId, kind),
                intent,
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )

            if (pendingIntent != null) {
                alarmManager.cancel(pendingIntent)
                pendingIntent.cancel()
            }
        }
    }

    /** Returns the same monthly cycle on the next month, clamping 29/30/31 safely. */
    fun nextMonthlyDueAt(dueAt: Long): Long {
        val c = Calendar.getInstance().apply { timeInMillis = dueAt }
        val desiredDay = c.get(Calendar.DAY_OF_MONTH)
        c.set(Calendar.DAY_OF_MONTH, 1)
        c.add(Calendar.MONTH, 1)
        val maxDay = c.getActualMaximum(Calendar.DAY_OF_MONTH)
        c.set(Calendar.DAY_OF_MONTH, minOf(desiredDay, maxDay))
        return c.timeInMillis
    }

    fun scheduleAll(context: Context, bills: List<Bill>) {
        bills.forEach { schedule(context, it) }
    }
}
