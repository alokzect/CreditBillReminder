# Build APK from a phone with GitHub Actions

1. Create a GitHub repository.
2. Upload the contents of this folder (not the ZIP itself) to the repository root.
3. Open **Actions** → **Build Credit Bill Reminder APK** → **Run workflow**.
4. Wait for the green build.
5. Open the workflow run and download the **CreditBillReminder-debug** artifact.
6. Extract the artifact ZIP and install the `.apk` on Android.

The workflow installs JDK 17, Android SDK 35/build-tools 35.0.0 and Gradle 8.9, so a PC or local Android build environment is not required.
