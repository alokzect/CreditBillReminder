package com.axiom.creditbill.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.axiom.creditbill.R
import com.axiom.creditbill.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            rescheduleAll(context)
            return
        }

        if (intent.action != "com.axiom.creditbill.REMINDER") return

        val id = intent.getLongExtra("billId", -1L)
        if (id < 0) return

        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.get(context)
                val bill = db.dao().get(id) ?: return@launch
                if (bill.paid) return@launch

                val amount = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
                    .format(bill.amount)
                val dueToday = intent.getBooleanExtra("dueToday", false)

                showNotification(
                    context,
                    "${bill.cardName} •••• ${bill.lastFour}",
                    if (dueToday) "$amount is due today." else "$amount is due soon."
                )

                // Roll a recurring bill forward only when its actual due-day
                // alarm fires. The earlier reminder must never advance the cycle.
                if (dueToday && bill.recurringMonthly) {
                    val nextDue = ReminderScheduler.nextMonthlyDueAt(bill.dueAt)
                    val nextBill = bill.copy(
                        dueAt = nextDue,
                        paid = false
                    )
                    db.dao().update(nextBill)
                    ReminderScheduler.schedule(context, nextBill)
                }
            } finally {
                pending.finish()
            }
        }
    }

    private fun rescheduleAll(context: Context) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val bills = AppDatabase.get(context).dao().getAll()
                ReminderScheduler.scheduleAll(context, bills.filter { !it.paid })
            } finally {
                pending.finish()
            }
        }
    }

    private fun showNotification(context: Context, title: String, message: String) {
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                "bill_reminders",
                "Bill Reminders",
                NotificationManager.IMPORTANCE_HIGH
            )
        )

        manager.notify(
            (System.currentTimeMillis() and 0x7fffffff).toInt(),
            NotificationCompat.Builder(context, "bill_reminders")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(message)
                .setAutoCancel(true)
                .build()
        )
    }
}
