package com.axiom.creditbill

import android.app.*
import android.os.Bundle
import android.os.Build
import android.provider.Settings
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.room.Room
import com.axiom.creditbill.data.*
import com.axiom.creditbill.worker.ReminderScheduler
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity:ComponentActivity(){
 private val notificationPermission=registerForActivityResult(ActivityResultContracts.RequestPermission()){}
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED) notificationPermission.launch("android.permission.POST_NOTIFICATIONS")
  val db=AppDatabase.get(this); val dao=db.dao()
  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !db.getOpenHelper().writableDatabase.isReadOnly && !com.axiom.creditbill.worker.ReminderScheduler.canScheduleExact(this)) {
   val prefs=getSharedPreferences("settings", MODE_PRIVATE)
   if (!prefs.getBoolean("exact_alarm_prompted", false)) {
    prefs.edit().putBoolean("exact_alarm_prompted", true).apply()
    runCatching { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
   }
  }
  kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
   com.axiom.creditbill.worker.ReminderScheduler.scheduleAll(this@MainActivity, dao.getAll().filter { !it.paid })
  }
  setContent{ MaterialTheme{ App(dao,this) } }
 }
}

@Composable fun App(dao:BillDao,context:android.content.Context){
 val scope=rememberCoroutineScope(); val bills by dao.observe().collectAsStateWithLifecycle(emptyList()); var add by remember{mutableStateOf(false)}
 Scaffold(topBar={TopAppBar(title={Text("Credit Bill Reminder")})},floatingActionButton={FloatingActionButton({add=true}){Text("+")}}){p->
  Column(Modifier.padding(p).padding(16.dp)){Text("Pending: ₹%.2f".format(Locale.US,bills.filter{!it.paid}.sumOf{it.amount}),style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.height(12.dp));
   LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(bills,key={it.id}){b->BillRow(b,{scope.launch{
    if (!b.paid && b.recurringMonthly) {
     val next=b.copy(dueAt=ReminderScheduler.nextMonthlyDueAt(b.dueAt), paid=false)
     dao.update(next)
     ReminderScheduler.schedule(context,next)
    } else {
     val x=b.copy(paid=!b.paid); dao.update(x)
     if(x.paid) ReminderScheduler.cancel(context,x.id) else ReminderScheduler.schedule(context,x)
    }
   }} ,{scope.launch{dao.delete(b);ReminderScheduler.cancel(context,b.id)}})}}
  }
 }
 if(add) AddDialog({add=false}){b->scope.launch{val id=dao.insert(b);ReminderScheduler.schedule(context,b.copy(id=id));add=false}}
}

@Composable fun BillRow(b:Bill,onPaid:()->Unit,onDelete:()->Unit){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("${b.cardName}  •••• ${b.lastFour}",style=MaterialTheme.typography.titleMedium);Text("₹%.2f • Due %s".format(Locale.US,b.amount,SimpleDateFormat("dd MMM yyyy",Locale.getDefault()).format(Date(b.dueAt))));Text(if(b.paid)"PAID" else "Reminder: ${b.reminderDays} day(s) before");Row{Button(onPaid){Text(if(b.paid)"Mark Unpaid" else "Mark Paid")};Spacer(Modifier.width(8.dp));OutlinedButton(onDelete){Text("Delete")}}}}}

@Composable fun AddDialog(onDismiss:()->Unit,onSave:(Bill)->Unit){
 var name by remember{mutableStateOf("")}
 var last4 by remember{mutableStateOf("")}
 var amount by remember{mutableStateOf("")}
 var days by remember{mutableStateOf("3")}
 var hour by remember{mutableStateOf("9")}
 var minute by remember{mutableStateOf("0")}
 var recurring by remember{mutableStateOf(false)}
 var due by remember{mutableStateOf(Calendar.getInstance().apply{add(Calendar.DAY_OF_YEAR,30)})}
 AlertDialog(onDismissRequest=onDismiss,title={Text("Add bill")},text={
  Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
   OutlinedTextField(name,{name=it},label={Text("Card name")})
   OutlinedTextField(last4,{if(it.length<=4)last4=it.filter(Char::isDigit)},label={Text("Last 4 digits")})
   OutlinedTextField(amount,{amount=it},label={Text("Amount")})
   Text("Due date: ${SimpleDateFormat("dd MMM yyyy",Locale.getDefault()).format(due.time)}")
   Row{Button({due.add(Calendar.DAY_OF_YEAR,1)}){Text("+1 day")};Spacer(Modifier.width(8.dp));Button({due.add(Calendar.DAY_OF_YEAR,-1)}){Text("-1 day")}}
   OutlinedTextField(days,{days=it.filter(Char::isDigit)},label={Text("Reminder days before")})
   Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
    OutlinedTextField(hour,{hour=it.filter(Char::isDigit).take(2)},label={Text("Hour")},modifier=Modifier.weight(1f))
    OutlinedTextField(minute,{minute=it.filter(Char::isDigit).take(2)},label={Text("Minute")},modifier=Modifier.weight(1f))
   }
   Row{Checkbox(recurring,{recurring=it});Text("Repeat monthly",modifier=Modifier.padding(top=12.dp))}
  }
 },confirmButton={TextButton(enabled=name.isNotBlank()&&last4.length==4&&amount.toDoubleOrNull()!=null,onClick={
  val h=(hour.toIntOrNull()?:9).coerceIn(0,23); val m=(minute.toIntOrNull()?:0).coerceIn(0,59)
  val d=(days.toIntOrNull()?:3).coerceIn(0,365)
  val normalized=Calendar.getInstance().apply{timeInMillis=due.timeInMillis;set(Calendar.HOUR_OF_DAY,h);set(Calendar.MINUTE,m);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}
  onSave(Bill(cardName=name,lastFour=last4,amount=amount.toDouble(),dueAt=normalized.timeInMillis,reminderDays=d,reminderHour=h,reminderMinute=m,recurringMonthly=recurring))
}){Text("Save")}},dismissButton={TextButton(onDismiss){Text("Cancel")}})
}
