package com.axiom.creditbill.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName="bills")
data class Bill(
 @PrimaryKey(autoGenerate=true) val id:Long=0,
 val cardName:String,
 val lastFour:String,
 val amount:Double,
 val dueAt:Long,
 val reminderDays:Int=3,
 val reminderHour:Int=9,
 val reminderMinute:Int=0,
 val recurringMonthly:Boolean=false,
 val paid:Boolean=false,
 val notes:String=""
)
