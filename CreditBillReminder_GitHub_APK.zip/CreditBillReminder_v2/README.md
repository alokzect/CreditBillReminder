# Credit Bill Reminder v2.1

Offline Android credit-card bill reminder.

## Reminder behavior
- Reminder alarm: configurable number of days before the due date.
- Due-day alarm: fires on the due date at the selected reminder time.
- If reminder days = 0, only one due-day notification is scheduled.
- Marking a normal bill Paid cancels its pending alarms.
- Monthly recurring bills advance to the next monthly cycle when the due-day alarm fires.
- Marking a recurring bill Paid immediately advances it to the next monthly cycle and schedules that cycle.
- Monthly dates are safely clamped (for example Jan 31 -> Feb 28/29).
- Alarms are restored after device reboot and app replacement.
- Android 12+ exact-alarm access is requested once; if unavailable, the app safely falls back to an inexact idle-safe alarm instead of crashing.
- Notification permission is requested on Android 13+.
- Data is stored locally in Room. No network/API is required.
- Only the last four card digits are stored; never store a full card number or CVV.
